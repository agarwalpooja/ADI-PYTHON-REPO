import setuptools

setuptools.setup(
    include_package_data=True,
    name='myadipkg',
    version='0.0.1',
    description='pooja"s ADI python package module',
    url='https://github.com/hkshitesh/mydemopackage',
    author='pagarwa3',
    author_email='poojaag1606@gmail.com',
    packages=setuptools.find_packages(),    
    long_description='pooja ADI python package module',
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
         "Operating System :: OS Independent",
    ],
)
#https://github.com/hkshitesh/hkshiteshpkg